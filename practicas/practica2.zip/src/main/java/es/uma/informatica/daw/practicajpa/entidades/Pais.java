package es.uma.informatica.daw.practicajpa.entidades;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class Pais {
    private Long id;
    private String nombre;
    private Long habitantes;
    private Federacion federacion;
    private Set<Pais> colindantes;
}
