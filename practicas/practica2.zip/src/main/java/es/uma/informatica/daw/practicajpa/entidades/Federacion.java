package es.uma.informatica.daw.practicajpa.entidades;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class Federacion {
    private Long id;
    private String nombre;
    private Set<Pais> paises;

}
